import re

_P = re.compile(r"^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$")


def parse_duration(s):
    s = s.strip().lower()
    m = _P.match(s)
    if not s or not m:
        raise ValueError(f"invalid duration: {s!r}")
    h, mi, se = (int(x or 0) for x in m.groups())
    return h * 3600 + mi * 60 + se
