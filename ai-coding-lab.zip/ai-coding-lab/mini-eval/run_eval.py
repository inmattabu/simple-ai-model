import glob
import os
import subprocess
import sys
from math import comb

files = sorted(glob.glob("samples/*.py"))
if not files:
    sys.exit("Put model-generated solutions in samples/*.py first (see SPEC.md)")


def pass_at_k(n, c, k):
    return 1.0 if n - c < k else 1 - comb(n - c, k) / comb(n, k)


n, c = len(files), 0
for f in files:
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "tests"],
                       env={**os.environ, "SAMPLE": os.path.abspath(f)}, capture_output=True)
    ok = r.returncode == 0
    c += ok
    print(("PASS  " if ok else "FAIL  ") + f)
print(f"n={n} correct={c}")
for k in (1, 5):
    if k <= n:
        print(f"pass@{k} = {pass_at_k(n, c, k):.2f}")
