import importlib.util
import os
import pathlib
import pytest

default = pathlib.Path(__file__).parent.parent / "reference" / "duration_reference.py"
spec = importlib.util.spec_from_file_location("sample", os.getenv("SAMPLE", str(default)))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
parse = mod.parse_duration


@pytest.mark.parametrize("s,expected", [
    ("1h30m", 5400), ("45s", 45), ("2h", 7200), ("1h30m15s", 5415),
    ("90m", 5400), (" 10s ", 10), ("1H", 3600), ("0s", 0),
])
def test_valid(s, expected):
    assert parse(s) == expected


@pytest.mark.parametrize("s", ["", "abc", "1x", "h", "30m1h", "1h 30m", "-5s"])
def test_invalid(s):
    with pytest.raises(ValueError):
        parse(s)
