# Spec: parse_duration(s: str) -> int
Convert strings like "1h30m", "45s", "2h", "1h30m15s" to total seconds.
- Units are h, m, s, each optional, in that order only (h before m before s).
- Surrounding whitespace is ignored; input is case-insensitive.
- Empty, unknown units, or wrong order (e.g. "30m1h") raise ValueError.
Ask the model for 5 independent implementations; save as samples/s1.py ... s5.py
(each must define parse_duration). Then run: python run_eval.py
