# Prompt templates

## 1. Structured prompt
Goal: <what and for whom>
Stack/constraints: <languages, versions, no external CDNs, etc.>
Deliverables: <files, folder layout>
Acceptance criteria: <how I will verify it works>
Ask me questions first if anything is ambiguous.

## 2. Static site (Lab A)
Create a 3-page static site (Home, About, Contact) with one shared CSS file, semantic HTML,
responsive layout, no JavaScript frameworks and no external resources. Output the folder tree,
then every file in full. It will be served by nginx from site/index.html.

## 3. Nginx config review (Lab A)
Here is my nginx server block: <paste>. Explain each directive, then list security or
performance problems and the exact fix for each. Do not change anything I did not ask about.

## 4. Dynamic app (Lab B)
Extend the guestbook in app/main.py and web/index.html with: <feature>. Keep SQLite and
parameterized queries. Show a diff, not full files, and list any new dependency.

## 5. Debugging
Command run: <cmd>. Expected: <x>. Actual: <y>. Log output: <paste>.
Give the 3 most likely causes ranked, and one command to confirm each.

## 6. Security audit
Audit this code for injection, XSS, missing input limits, missing rate limiting and unsafe
defaults. For each finding give file, line, severity and a fix. Say "not found" when unsure.

## 7. Mini-eval samples (Module 8)
Implement parse_duration per the spec below. Return only Python code, no explanation.
<paste mini-eval/SPEC.md>   (run 5 times in fresh chats, save as samples/s1.py .. s5.py)
