import os
import sqlite3
from fastapi import FastAPI
from pydantic import BaseModel, Field

DB = os.getenv("DB_PATH", "/data/guestbook.db")
app = FastAPI()


def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


_c = conn()
_c.execute("CREATE TABLE IF NOT EXISTS entries (id INTEGER PRIMARY KEY, name TEXT NOT NULL, "
           "message TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP)")
_c.commit()
_c.close()


class Entry(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    message: str = Field(min_length=1, max_length=500)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/entries")
def list_entries():
    c = conn()
    rows = c.execute("SELECT id, name, message, created FROM entries ORDER BY id DESC LIMIT 100").fetchall()
    c.close()
    return [dict(r) for r in rows]


@app.post("/entries", status_code=201)
def add_entry(e: Entry):
    c = conn()
    c.execute("INSERT INTO entries (name, message) VALUES (?, ?)", (e.name, e.message))
    c.commit()
    c.close()
    return {"ok": True}
